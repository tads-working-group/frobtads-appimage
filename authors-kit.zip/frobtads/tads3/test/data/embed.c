"try __FILE__ and __LINE__";
"__FILE__: <<__FILE__>>, __LINE__: << __LINE__ >>\n";

"__FILE__: <<
  __FILE__
  >>, __LINE__:
  <<
  __LINE__ >> -- that was __FILE and __LINE!\n";

